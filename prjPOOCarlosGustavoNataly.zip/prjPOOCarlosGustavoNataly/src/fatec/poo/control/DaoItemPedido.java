package fatec.poo.control;

import fatec.poo.model.ItemPedido;
import fatec.poo.model.Pedido;
import fatec.poo.model.Produto;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

public class DaoItemPedido {
    private Connection conn;
    private DaoProduto daoProduto;

    public DaoItemPedido(Connection conn) {
        this.conn = conn;
        daoProduto = new DaoProduto(conn);
    }

    public void inserir(ItemPedido itens) {
        PreparedStatement ps = null;
        try {
            ps = conn.prepareStatement("INSERT INTO ItemPedido"
                    + "(NumeroPedido,"
                    + "CodigoProduto,"
                    + "Sequencia,"
                    + "QtVendida) VALUES(?,?,?,?)");
            
                    ps.setString(1, itens.getPedido().getNumero());
                    ps.setString(2, itens.getProduto().getCodigo());
                    ps.setString(4, itens.getSequencia());
                    ps.setDouble(3, itens.getQtdeVendida());
        
        } catch (SQLException ex) {
            System.out.println(ex.toString());
        }
    }

    public void excluir(Pedido pedido) {
        PreparedStatement ps = null;
        try {
            ps = conn.prepareStatement("DELETE FROM itemPedido where numeroPedido = ?");
            ps.setString(1, pedido.getNumero());
            
            ps.execute();
        } catch (SQLException ex) {
            System.out.println(ex.toString());
        }
    }

    public void alterar(ItemPedido itemPedido) {
        PreparedStatement ps = null;
        try {           
            ps = conn.prepareStatement("UPDATE Cliente set Sequencia = ?, " 
					+ "QtVendida = ? WHERE NumeroPedido = ? AND CodigoProduto = ?");
            
            
            ps.setString(1, itemPedido.getSequencia());
            ps.setDouble(2, itemPedido.getQtdeVendida());
            ps.setString(3, itemPedido.getPedido().getNumero());
            ps.setString(4, itemPedido.getProduto().getCodigo());
            
            ps.execute();
        } catch (SQLException ex) {
             System.out.println(ex.toString());   
        }     
    }
    
    public ArrayList<ItemPedido> consultar(String numero, Pedido pedido) {
        ArrayList<ItemPedido> ip = new ArrayList<ItemPedido>();
        
        Produto produto = null;
        ItemPedido itemPedido = null;
        
        PreparedStatement ps = null;
        daoProduto = new DaoProduto(conn);
        try {
            ps = conn.prepareStatement("SELECT * from ItemPedido where NumeroPedido = ?");
            ps.setString(1, numero);
            
            ResultSet rs = ps.executeQuery();
            while (rs.next() == true) {
                produto = daoProduto.consultar(rs.getString("produto"));
                
                itemPedido = new ItemPedido (rs.getString("sequencia"), rs.getDouble("qtdeVendida"), produto);
                itemPedido.setPedido(pedido);
                
                ip.add(itemPedido);
            }
        } catch (SQLException ex) {
            System.out.println(ex.toString());
        }
        return ip;
    }
}
