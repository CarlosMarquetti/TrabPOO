/* 
@authors Carlos,
@authors Gustavo,
@authors Nataly;
 */
package fatec.poo.control;

import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Connection;
import java.sql.ResultSet;
import fatec.poo.model.Pedido;
import fatec.poo.model.Produto;

public class DaoPedido {
    private Connection conn;

    private DaoVendedor daoVendedor;
    private DaoCliente daoCliente;
    private DaoItemPedido daoItemPedido;
    private DaoProduto daoProduto;
    private Produto produto;

    public DaoPedido(Connection conn) {
        this.conn = conn;
    }

    public void inserir(Pedido pedido) {
        PreparedStatement ps = null;
        try {
            ps = conn.prepareStatement("INSERT INTO Pedido (Numero, CPFCliente, CPFVendedor, Status, DataPedido, DataPagto, FormaPagamento) VALUES (?, ?, ?, ?, ?, ?, ?)");

            ps.setString(1, pedido.getNumero());
            ps.setString(2, pedido.getCliente().getCpf());
            ps.setString(3, pedido.getVendedor().getCpf());
            
            if (pedido.getSituacao()) {
                ps.setString(4, "T");
            } else {
                ps.setString(4, "F");
            }
            
            ps.setString(5, pedido.getDataEmissao());
            ps.setString(6, pedido.getDataPagto());
            
            if (pedido.getFormaPagto()) {
                ps.setString(7, "P");
            } else {
                ps.setString(7, "V");
            }

            ps.execute();
        } catch (SQLException ex) {
            System.out.println(ex.toString());
        }
    }

    public Pedido consultar(String numeroPedido) {
        Pedido pedido = null;

        PreparedStatement ps = null;
        try {
            ps = conn.prepareStatement("SELECT * from Pedido where Numero = ?");
            ps.setString(1, numeroPedido);

            ResultSet rs = ps.executeQuery();
            if (rs.next() == true) {
                pedido = new Pedido(numeroPedido, rs.getString("DataPedido"));
                pedido.setDataPagto(rs.getString("DataPagto"));
                if ("P".equals(rs.getString("formaPagto"))) {
                    pedido.setFormaPagto(true);
                } else {
                    pedido.setFormaPagto(false);
                }

                daoCliente = new DaoCliente(conn);
                pedido.setCliente(daoCliente.consultar(rs.getString("CPFCliente")));

                daoVendedor = new DaoVendedor(conn);
                pedido.setVendedor(daoVendedor.consultar(rs.getString("CPFVendedor")));

                daoItemPedido = new DaoItemPedido(conn);
                pedido.setItemPedidos(daoItemPedido.consultar(numeroPedido, pedido));
            }
        } catch (SQLException ex) {
            System.out.println(ex.toString());
        }
        return (pedido);
    }

    public void excluir(Pedido pedido) {
        PreparedStatement ps = null;
        try {
            if (pedido.getFormaPagto()) {
                pedido.getCliente().setLimiteDisp(pedido.getCliente().getLimiteDisp() + pedido.calcTotal());
                daoCliente = new DaoCliente(conn);
                daoCliente.alterar(pedido.getCliente());
            }

            daoProduto = new DaoProduto(conn);
            for (int i = 0; i < pedido.getItemPedidos().size(); i++) {
                produto = pedido.getItemPedidos().get(i).getProduto();
                produto.setQtdeEstoque(produto.getQtdeEstoque() + pedido.getItemPedidos().get(i).getQtdeVendida());
                daoProduto.alterar(produto);
            }

            ps = conn.prepareStatement("DELETE FROM ItemPedido WHERE pedido = ?");
            ps.setString(1, pedido.getNumero());
            ps.execute();

            ps = conn.prepareStatement("DELETE FROM Pedido WHERE numero = ?");
            ps.setString(1, pedido.getNumero());
            ps.execute();
        } catch (SQLException ex) {
            System.out.println(ex.toString());
        }
    }
}
