package fatec.poo.view;

import fatec.poo.control.Conexao;
import fatec.poo.control.DaoCliente;
import fatec.poo.control.DaoItemPedido;
import fatec.poo.control.DaoPedido;
import fatec.poo.control.DaoProduto;
import fatec.poo.control.DaoVendedor;
import fatec.poo.model.Cliente;
import fatec.poo.model.ItemPedido;
import fatec.poo.model.Pedido;
import fatec.poo.model.Produto;
import fatec.poo.model.Vendedor;
import java.text.DecimalFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

/* 
@authors Carlos,
@authors Gustavo,
@authors Nataly;
 */
public class GuiEmitirPedido extends javax.swing.JFrame {

    public GuiEmitirPedido() {
        initComponents();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        buttonGroup1 = new javax.swing.ButtonGroup();
        buttonGroup2 = new javax.swing.ButtonGroup();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        buttonGroup3 = new javax.swing.ButtonGroup();
        buttonGroup4 = new javax.swing.ButtonGroup();
        buttonGroup5 = new javax.swing.ButtonGroup();
        pnDadosPedido = new javax.swing.JPanel();
        btnConsultarPedido = new javax.swing.JButton();
        lblNumeroPedido = new javax.swing.JLabel();
        txtNumeroPedido = new javax.swing.JTextField();
        lblDataPedido = new javax.swing.JLabel();
        painelFormaPagamento = new javax.swing.JPanel();
        rdbtnPagamentoAVista = new javax.swing.JRadioButton();
        rdbtnPagamentoAPrazo = new javax.swing.JRadioButton();
        txtDataPedido = new javax.swing.JFormattedTextField();
        pnDadosCliente = new javax.swing.JPanel();
        lblCPFCliente = new javax.swing.JLabel();
        btnConsultarCliente = new javax.swing.JButton();
        txtCPFCliente = new javax.swing.JFormattedTextField();
        lblCliente = new javax.swing.JLabel();
        pnDadosVendedor = new javax.swing.JPanel();
        lblCPFVendedor = new javax.swing.JLabel();
        btnConsultarVendedor = new javax.swing.JButton();
        txtCPFVendedor = new javax.swing.JFormattedTextField();
        lblVendedor = new javax.swing.JLabel();
        pnItensDoPedido = new javax.swing.JPanel();
        lblCodigoProduto = new javax.swing.JLabel();
        txtCodigoProduto = new javax.swing.JTextField();
        btnConsultarItemPedido = new javax.swing.JButton();
        lblQtdeVendida = new javax.swing.JLabel();
        txtQtdeVendida = new javax.swing.JTextField();
        btnAdicionarItem = new javax.swing.JButton();
        btnRemoverItem = new javax.swing.JButton();
        jScrollPane2 = new javax.swing.JScrollPane();
        tblItens = new javax.swing.JTable();
        lblValorTotalPedido = new javax.swing.JLabel();
        lblQtdeItensPedido = new javax.swing.JLabel();
        lblProduto = new javax.swing.JLabel();
        lblValorTotal = new javax.swing.JLabel();
        lblQuantItensPedidos = new javax.swing.JLabel();
        btnIncluir = new javax.swing.JButton();
        btnAlterar = new javax.swing.JButton();
        btnExcluir = new javax.swing.JButton();
        btnSair = new javax.swing.JButton();

        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jScrollPane1.setViewportView(jTable1);

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Emitir Pedido");
        addWindowListener(new java.awt.event.WindowAdapter() {
            public void windowOpened(java.awt.event.WindowEvent evt) {
                formWindowOpened(evt);
            }
        });

        pnDadosPedido.setBorder(javax.swing.BorderFactory.createTitledBorder("Pedido"));
        pnDadosPedido.setToolTipText("");
        pnDadosPedido.setName(""); // NOI18N

        btnConsultarPedido.setIcon(new javax.swing.ImageIcon(getClass().getResource("/fatec/poo/view/icon/pesq.png"))); // NOI18N
        btnConsultarPedido.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnConsultarPedidoActionPerformed(evt);
            }
        });

        lblNumeroPedido.setText("Número do Pedido");

        lblDataPedido.setText("Data do Pedido");

        painelFormaPagamento.setBorder(javax.swing.BorderFactory.createTitledBorder("Forma de Pagamento"));
        painelFormaPagamento.setDoubleBuffered(false);
        painelFormaPagamento.setEnabled(false);

        buttonGroup1.add(rdbtnPagamentoAVista);
        rdbtnPagamentoAVista.setSelected(true);
        rdbtnPagamentoAVista.setText("A Vista");
        rdbtnPagamentoAVista.setEnabled(false);

        buttonGroup1.add(rdbtnPagamentoAPrazo);
        rdbtnPagamentoAPrazo.setText("A Prazo");
        rdbtnPagamentoAPrazo.setEnabled(false);

        javax.swing.GroupLayout painelFormaPagamentoLayout = new javax.swing.GroupLayout(painelFormaPagamento);
        painelFormaPagamento.setLayout(painelFormaPagamentoLayout);
        painelFormaPagamentoLayout.setHorizontalGroup(
            painelFormaPagamentoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(painelFormaPagamentoLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(rdbtnPagamentoAVista)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 18, Short.MAX_VALUE)
                .addComponent(rdbtnPagamentoAPrazo)
                .addContainerGap())
        );
        painelFormaPagamentoLayout.setVerticalGroup(
            painelFormaPagamentoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(painelFormaPagamentoLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(painelFormaPagamentoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(rdbtnPagamentoAVista)
                    .addComponent(rdbtnPagamentoAPrazo))
                .addContainerGap(13, Short.MAX_VALUE))
        );

        try {
            txtDataPedido.setFormatterFactory(new javax.swing.text.DefaultFormatterFactory(new javax.swing.text.MaskFormatter("##/##/####")));
        } catch (java.text.ParseException ex) {
            ex.printStackTrace();
        }
        txtDataPedido.setEnabled(false);
        txtDataPedido.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusLost(java.awt.event.FocusEvent evt) {
                txtDataPedidoFocusLost(evt);
            }
        });

        javax.swing.GroupLayout pnDadosPedidoLayout = new javax.swing.GroupLayout(pnDadosPedido);
        pnDadosPedido.setLayout(pnDadosPedidoLayout);
        pnDadosPedidoLayout.setHorizontalGroup(
            pnDadosPedidoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnDadosPedidoLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(lblNumeroPedido)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(txtNumeroPedido, javax.swing.GroupLayout.PREFERRED_SIZE, 70, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(btnConsultarPedido, javax.swing.GroupLayout.PREFERRED_SIZE, 73, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(lblDataPedido)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(txtDataPedido, javax.swing.GroupLayout.PREFERRED_SIZE, 144, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(painelFormaPagamento, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        pnDadosPedidoLayout.linkSize(javax.swing.SwingConstants.HORIZONTAL, new java.awt.Component[] {txtDataPedido, txtNumeroPedido});

        pnDadosPedidoLayout.setVerticalGroup(
            pnDadosPedidoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnDadosPedidoLayout.createSequentialGroup()
                .addComponent(painelFormaPagamento, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 11, Short.MAX_VALUE))
            .addGroup(pnDadosPedidoLayout.createSequentialGroup()
                .addGap(21, 21, 21)
                .addGroup(pnDadosPedidoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(btnConsultarPedido, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(pnDadosPedidoLayout.createSequentialGroup()
                        .addGap(1, 1, 1)
                        .addGroup(pnDadosPedidoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(lblNumeroPedido)
                            .addComponent(txtNumeroPedido, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(pnDadosPedidoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(txtDataPedido, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(lblDataPedido)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        pnDadosPedidoLayout.linkSize(javax.swing.SwingConstants.VERTICAL, new java.awt.Component[] {btnConsultarPedido, txtDataPedido, txtNumeroPedido});

        pnDadosCliente.setBorder(javax.swing.BorderFactory.createTitledBorder("Dados Cliente"));

        lblCPFCliente.setText("CPF Cliente");

        btnConsultarCliente.setIcon(new javax.swing.ImageIcon(getClass().getResource("/fatec/poo/view/icon/pesq.png"))); // NOI18N
        btnConsultarCliente.setEnabled(false);
        btnConsultarCliente.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnConsultarClienteActionPerformed(evt);
            }
        });

        try {
            txtCPFCliente.setFormatterFactory(new javax.swing.text.DefaultFormatterFactory(new javax.swing.text.MaskFormatter("###.###.###-##")));
        } catch (java.text.ParseException ex) {
            ex.printStackTrace();
        }
        txtCPFCliente.setEnabled(false);

        lblCliente.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.LOWERED));

        javax.swing.GroupLayout pnDadosClienteLayout = new javax.swing.GroupLayout(pnDadosCliente);
        pnDadosCliente.setLayout(pnDadosClienteLayout);
        pnDadosClienteLayout.setHorizontalGroup(
            pnDadosClienteLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnDadosClienteLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(lblCPFCliente)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(txtCPFCliente, javax.swing.GroupLayout.PREFERRED_SIZE, 108, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(btnConsultarCliente, javax.swing.GroupLayout.PREFERRED_SIZE, 72, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(lblCliente, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );

        pnDadosClienteLayout.linkSize(javax.swing.SwingConstants.HORIZONTAL, new java.awt.Component[] {btnConsultarCliente, txtCPFCliente});

        pnDadosClienteLayout.setVerticalGroup(
            pnDadosClienteLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnDadosClienteLayout.createSequentialGroup()
                .addGap(24, 24, 24)
                .addGroup(pnDadosClienteLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(btnConsultarCliente, javax.swing.GroupLayout.PREFERRED_SIZE, 25, Short.MAX_VALUE)
                    .addGroup(pnDadosClienteLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(lblCPFCliente)
                        .addComponent(txtCPFCliente, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(lblCliente, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap(37, Short.MAX_VALUE))
        );

        pnDadosClienteLayout.linkSize(javax.swing.SwingConstants.VERTICAL, new java.awt.Component[] {btnConsultarCliente, txtCPFCliente});

        pnDadosVendedor.setBorder(javax.swing.BorderFactory.createTitledBorder("Dados Vendedor"));

        lblCPFVendedor.setText("CPF Vendedor");

        btnConsultarVendedor.setIcon(new javax.swing.ImageIcon(getClass().getResource("/fatec/poo/view/icon/pesq.png"))); // NOI18N
        btnConsultarVendedor.setEnabled(false);
        btnConsultarVendedor.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnConsultarVendedorActionPerformed(evt);
            }
        });

        try {
            txtCPFVendedor.setFormatterFactory(new javax.swing.text.DefaultFormatterFactory(new javax.swing.text.MaskFormatter("###.###.###-##")));
        } catch (java.text.ParseException ex) {
            ex.printStackTrace();
        }
        txtCPFVendedor.setEnabled(false);

        lblVendedor.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.LOWERED));

        javax.swing.GroupLayout pnDadosVendedorLayout = new javax.swing.GroupLayout(pnDadosVendedor);
        pnDadosVendedor.setLayout(pnDadosVendedorLayout);
        pnDadosVendedorLayout.setHorizontalGroup(
            pnDadosVendedorLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnDadosVendedorLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(lblCPFVendedor)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(txtCPFVendedor, javax.swing.GroupLayout.PREFERRED_SIZE, 122, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(btnConsultarVendedor, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGap(18, 18, 18)
                .addComponent(lblVendedor, javax.swing.GroupLayout.PREFERRED_SIZE, 446, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );
        pnDadosVendedorLayout.setVerticalGroup(
            pnDadosVendedorLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnDadosVendedorLayout.createSequentialGroup()
                .addGap(24, 24, 24)
                .addGroup(pnDadosVendedorLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(btnConsultarVendedor, javax.swing.GroupLayout.PREFERRED_SIZE, 25, Short.MAX_VALUE)
                    .addGroup(pnDadosVendedorLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(lblCPFVendedor)
                        .addComponent(txtCPFVendedor, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(lblVendedor, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap(37, Short.MAX_VALUE))
        );

        pnDadosVendedorLayout.linkSize(javax.swing.SwingConstants.VERTICAL, new java.awt.Component[] {btnConsultarVendedor, txtCPFVendedor});

        pnItensDoPedido.setBorder(javax.swing.BorderFactory.createTitledBorder("Itens do Pedido"));

        lblCodigoProduto.setText("Código Produto");

        txtCodigoProduto.setEnabled(false);

        btnConsultarItemPedido.setIcon(new javax.swing.ImageIcon(getClass().getResource("/fatec/poo/view/icon/pesq.png"))); // NOI18N
        btnConsultarItemPedido.setToolTipText("");
        btnConsultarItemPedido.setEnabled(false);
        btnConsultarItemPedido.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnConsultarItemPedidoActionPerformed(evt);
            }
        });

        lblQtdeVendida.setText("Qtde. vendida");

        txtQtdeVendida.setEnabled(false);

        btnAdicionarItem.setIcon(new javax.swing.ImageIcon(getClass().getResource("/fatec/poo/view/icon/add.png"))); // NOI18N
        btnAdicionarItem.setText("Adicionar Item");
        btnAdicionarItem.setToolTipText("");
        btnAdicionarItem.setEnabled(false);
        btnAdicionarItem.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAdicionarItemActionPerformed(evt);
            }
        });

        btnRemoverItem.setIcon(new javax.swing.ImageIcon(getClass().getResource("/fatec/poo/view/icon/rem.png"))); // NOI18N
        btnRemoverItem.setText("Remover Item");
        btnRemoverItem.setEnabled(false);
        btnRemoverItem.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnRemoverItemActionPerformed(evt);
            }
        });

        tblItens.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Código", "Descrição", "Prec. Unit.", "Qtde. Vend.", "SubTotal"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class
            };
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jScrollPane2.setViewportView(tblItens);

        lblValorTotalPedido.setText("Valor Total do Pedido");

        lblQtdeItensPedido.setText("Quantidade de itens do Pedido");

        lblProduto.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.LOWERED));

        lblValorTotal.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.LOWERED));

        lblQuantItensPedidos.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.LOWERED));

        javax.swing.GroupLayout pnItensDoPedidoLayout = new javax.swing.GroupLayout(pnItensDoPedido);
        pnItensDoPedido.setLayout(pnItensDoPedidoLayout);
        pnItensDoPedidoLayout.setHorizontalGroup(
            pnItensDoPedidoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnItensDoPedidoLayout.createSequentialGroup()
                .addGroup(pnItensDoPedidoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, pnItensDoPedidoLayout.createSequentialGroup()
                        .addComponent(btnAdicionarItem, javax.swing.GroupLayout.PREFERRED_SIZE, 132, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(btnRemoverItem, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGap(11, 11, 11))
                    .addGroup(pnItensDoPedidoLayout.createSequentialGroup()
                        .addContainerGap()
                        .addGroup(pnItensDoPedidoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jScrollPane2)
                            .addGroup(pnItensDoPedidoLayout.createSequentialGroup()
                                .addComponent(lblCodigoProduto)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(txtCodigoProduto, javax.swing.GroupLayout.PREFERRED_SIZE, 70, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(13, 13, 13)
                                .addComponent(btnConsultarItemPedido, javax.swing.GroupLayout.PREFERRED_SIZE, 70, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(18, 18, 18)
                                .addComponent(lblProduto, javax.swing.GroupLayout.PREFERRED_SIZE, 331, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(18, 18, 18)
                                .addComponent(lblQtdeVendida)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(txtQtdeVendida, javax.swing.GroupLayout.PREFERRED_SIZE, 70, javax.swing.GroupLayout.PREFERRED_SIZE))))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, pnItensDoPedidoLayout.createSequentialGroup()
                        .addGroup(pnItensDoPedidoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(lblValorTotalPedido)
                            .addComponent(lblQtdeItensPedido))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(pnItensDoPedidoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(lblValorTotal, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(lblQuantItensPedidos, javax.swing.GroupLayout.DEFAULT_SIZE, 147, Short.MAX_VALUE))))
                .addContainerGap())
        );

        pnItensDoPedidoLayout.linkSize(javax.swing.SwingConstants.HORIZONTAL, new java.awt.Component[] {btnAdicionarItem, btnRemoverItem});

        pnItensDoPedidoLayout.setVerticalGroup(
            pnItensDoPedidoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnItensDoPedidoLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(pnItensDoPedidoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(btnConsultarItemPedido, javax.swing.GroupLayout.PREFERRED_SIZE, 25, Short.MAX_VALUE)
                    .addGroup(pnItensDoPedidoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(lblCodigoProduto)
                        .addComponent(txtCodigoProduto, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(lblQtdeVendida)
                        .addComponent(txtQtdeVendida, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(lblProduto, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addGap(18, 18, 18)
                .addGroup(pnItensDoPedidoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnAdicionarItem, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnRemoverItem, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 86, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addGroup(pnItensDoPedidoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(lblValorTotal, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(lblValorTotalPedido, javax.swing.GroupLayout.DEFAULT_SIZE, 25, Short.MAX_VALUE))
                .addGap(26, 26, 26)
                .addGroup(pnItensDoPedidoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblQuantItensPedidos, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lblQtdeItensPedido, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(32, Short.MAX_VALUE))
        );

        pnItensDoPedidoLayout.linkSize(javax.swing.SwingConstants.VERTICAL, new java.awt.Component[] {btnConsultarItemPedido, txtCodigoProduto});

        pnItensDoPedidoLayout.linkSize(javax.swing.SwingConstants.VERTICAL, new java.awt.Component[] {btnAdicionarItem, btnRemoverItem});

        btnIncluir.setIcon(new javax.swing.ImageIcon(getClass().getResource("/fatec/poo/view/icon/save.png"))); // NOI18N
        btnIncluir.setText("Incluir");
        btnIncluir.setEnabled(false);
        btnIncluir.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnIncluirActionPerformed(evt);
            }
        });

        btnAlterar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/fatec/poo/view/icon/Alterar.png"))); // NOI18N
        btnAlterar.setText("Alterar");
        btnAlterar.setEnabled(false);
        btnAlterar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAlterarActionPerformed(evt);
            }
        });

        btnExcluir.setIcon(new javax.swing.ImageIcon(getClass().getResource("/fatec/poo/view/icon/Eraser.png"))); // NOI18N
        btnExcluir.setText("Excluir");
        btnExcluir.setEnabled(false);

        btnSair.setIcon(new javax.swing.ImageIcon(getClass().getResource("/fatec/poo/view/icon/exit.png"))); // NOI18N
        btnSair.setText("Sair");
        btnSair.setToolTipText("");
        btnSair.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSairActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(pnItensDoPedido, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(pnDadosVendedor, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(pnDadosCliente, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(pnDadosPedido, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addGap(0, 0, Short.MAX_VALUE)
                        .addComponent(btnIncluir, javax.swing.GroupLayout.PREFERRED_SIZE, 90, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(btnAlterar, javax.swing.GroupLayout.PREFERRED_SIZE, 90, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(btnExcluir, javax.swing.GroupLayout.PREFERRED_SIZE, 90, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(btnSair, javax.swing.GroupLayout.PREFERRED_SIZE, 71, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap())
        );

        layout.linkSize(javax.swing.SwingConstants.HORIZONTAL, new java.awt.Component[] {btnAlterar, btnExcluir, btnIncluir, btnSair});

        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(pnDadosPedido, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(pnDadosCliente, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(pnDadosVendedor, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(pnItensDoPedido, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnIncluir, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnAlterar, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnExcluir, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnSair, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(12, Short.MAX_VALUE))
        );

        layout.linkSize(javax.swing.SwingConstants.VERTICAL, new java.awt.Component[] {btnAlterar, btnExcluir, btnIncluir, btnSair});

        pnDadosPedido.getAccessibleContext().setAccessibleName("");

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnConsultarClienteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnConsultarClienteActionPerformed
        cliente = null;

        cliente = daoCliente.consultar(txtCPFCliente.getText());
        try {
            if (cliente == null) {
                JOptionPane.showMessageDialog(null, "Cliente Não encontrado!", "ERRO", JOptionPane.WARNING_MESSAGE);
            } else {
                lblCliente.setText(cliente.getNome());

                txtCPFCliente.setEnabled(false);
                txtDataPedido.setEnabled(false);
                btnConsultarCliente.setEnabled(false);
                rdbtnPagamentoAVista.setEnabled(false);
                rdbtnPagamentoAPrazo.setEnabled(false);

                txtCPFVendedor.setEnabled(true);
                btnConsultarVendedor.setEnabled(true);

                txtCPFVendedor.requestFocus();
            }

        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(null, "Entradas inválidas!", "ERRO", JOptionPane.WARNING_MESSAGE);
            txtCPFCliente.setText("");
            txtCPFCliente.requestFocus();
        }
    }//GEN-LAST:event_btnConsultarClienteActionPerformed

    private void btnSairActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSairActionPerformed
        dispose();
    }//GEN-LAST:event_btnSairActionPerformed

    private void formWindowOpened(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_formWindowOpened
        conexao = new Conexao("Carlos", "1234");
        conexao.setDriver("oracle.jdbc.driver.OracleDriver");
        conexao.setConnectionString("jdbc:oracle:thin:@127.0.0.1:1521:xe");
        daoPedido = new DaoPedido(conexao.conectar());
        daoCliente = new DaoCliente(conexao.conectar());
        daoVendedor = new DaoVendedor(conexao.conectar());
        daoProduto = new DaoProduto(conexao.conectar());
        daoItemPedido = new DaoItemPedido(conexao.conectar());
    }//GEN-LAST:event_formWindowOpened

    private void btnConsultarPedidoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnConsultarPedidoActionPerformed
        String codigo = txtNumeroPedido.getText();
        pedido = null;
        double valorTotal = 0;
        try {
            if (!codigo.matches("\\d+")) {
                JOptionPane.showMessageDialog(this, "O código deve conter apenas dígitos numéricos.",
                        "Erro de entrada", JOptionPane.ERROR_MESSAGE);
                return;
            } else {
                pedido = daoPedido.consultar(txtCodigoProduto.getText());
                if (pedido == null) {
                    btnConsultarPedido.setEnabled(false);
                    txtNumeroPedido.setEnabled(false);

                    txtCPFCliente.requestFocus();

                    txtDataPedido.setEnabled(true);
                    rdbtnPagamentoAVista.setEnabled(true);
                    rdbtnPagamentoAPrazo.setEnabled(true);

                    txtCPFCliente.setEnabled(true);
                    btnConsultarCliente.setEnabled(true);
                } else {
                    txtNumeroPedido.setEnabled(false);
                    btnConsultarPedido.setEnabled(false);
                    txtDataPedido.setText(pedido.getDataEmissao());
                    txtDataPedido.setEnabled(false);

                    if (pedido.getFormaPagto()) {
                        rdbtnPagamentoAPrazo.setSelected(true);
                    }

                    rdbtnPagamentoAPrazo.setEnabled(false);
                    rdbtnPagamentoAVista.setEnabled(false);

                    txtCPFCliente.setText(pedido.getCliente().getCpf());
                    lblCliente.setText(pedido.getCliente().getNome());
                    txtCPFCliente.setEnabled(false);
                    btnConsultarCliente.setEnabled(false);

                    txtCPFVendedor.setText(pedido.getVendedor().getCpf());
                    lblVendedor.setText(pedido.getVendedor().getNome());
                    txtCPFVendedor.setEnabled(false);

                    btnConsultarVendedor.setEnabled(false);
                    txtCodigoProduto.setEnabled(true);
                    btnConsultarItemPedido.setEnabled(true);

                    txtDataPedido.setText(pedido.getDataEmissao());
                    txtCPFCliente.setText(pedido.getCliente().getCpf());
                    lblCliente.setText(pedido.getCliente().getNome());
                    txtCPFVendedor.setText(pedido.getVendedor().getCpf());
                    lblVendedor.setText(pedido.getVendedor().getNome());

                    for (int i = 0; i < pedido.getItemPedidos().size(); i++) {
                        String linha[] = {
                            pedido.getItemPedidos().get(i).getProduto().getCodigo(),
                            pedido.getItemPedidos().get(i).getProduto().getDescricao(),
                            pedido.getItemPedidos().get(i).getProduto().getPreco() + "",
                            pedido.getItemPedidos().get(i).getQtdeVendida() + "",
                            (pedido.getItemPedidos().get(i).getQtdeVendida() * pedido.getItemPedidos().get(i).getProduto().getPreco()) + ""
                        };
                        modTblItens.addRow(linha);

                        btnExcluir.setEnabled(true);
                        btnIncluir.setEnabled(false);
                        btnAlterar.setEnabled(true);
                        btnExcluir.setEnabled(true);
                    }
                }
            }
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(null, "Pedido Inexistente!", "ERRO", JOptionPane.WARNING_MESSAGE);
            txtNumeroPedido.setText("");
            txtNumeroPedido.requestFocus();
        }
    }//GEN-LAST:event_btnConsultarPedidoActionPerformed

    private void btnConsultarVendedorActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnConsultarVendedorActionPerformed
        vendedor = null;

        vendedor = daoVendedor.consultar(txtCPFVendedor.getText());
        try {
            if (cliente == null) {
                JOptionPane.showMessageDialog(null, "Vendedor não encontrado!", "ERRO", JOptionPane.WARNING_MESSAGE);
            } else {
                lblVendedor.setText(vendedor.getNome());

                txtCPFVendedor.setEnabled(false);
                btnConsultarVendedor.setEnabled(false);

                txtCodigoProduto.setEnabled(true);
                btnConsultarItemPedido.setEnabled(true);

                txtCodigoProduto.requestFocus();
            }
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(null, "Entradas inválidas!", "ERRO", JOptionPane.WARNING_MESSAGE);
            txtCPFVendedor.setText("");
            txtCPFVendedor.requestFocus();
        }
    }//GEN-LAST:event_btnConsultarVendedorActionPerformed

    private void btnConsultarItemPedidoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnConsultarItemPedidoActionPerformed
        produto = null;
        produto = daoProduto.consultar(txtCodigoProduto.getText());
        try {
            if (produto == null) {
                JOptionPane.showMessageDialog(null, "Produto não encontrado!", "ERRO", JOptionPane.WARNING_MESSAGE);
            } else {
                lblProduto.setText(produto.getDescricao());
                btnAdicionarItem.setEnabled(true);
                btnRemoverItem.setEnabled(true);
                txtQtdeVendida.setEnabled(true);
                txtQtdeVendida.requestFocus();
            }
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(null, "Entradas inválidas!", "ERRO", JOptionPane.WARNING_MESSAGE);
            txtCodigoProduto.setText("");
            txtCodigoProduto.requestFocus();
        }
    }//GEN-LAST:event_btnConsultarItemPedidoActionPerformed

    private void btnIncluirActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnIncluirActionPerformed
        daoPedido.inserir(pedido);

        for (int i = 0; i < pedido.getItemPedidos().size(); i++) {
            daoItemPedido.inserir(pedido.getItemPedidos().get(i));
            daoProduto.alterar(pedido.getItemPedidos().get(i).getProduto());
            if (pedido.getFormaPagto()) {
                daoCliente.alterar(cliente);
            }
        }

        btnIncluir.setEnabled(false);
        btnAlterar.setEnabled(true);
        btnExcluir.setEnabled(true);
    }//GEN-LAST:event_btnIncluirActionPerformed

    private void btnAlterarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAlterarActionPerformed
        if (JOptionPane.showConfirmDialog(null, "Confirma Alteração?") == 0) {//Sim
            daoItemPedido.excluir(pedido);

            for (int i = 0; i < pedido.getItemPedidos().size(); i++) {
                daoItemPedido.inserir(pedido.getItemPedidos().get(i));
                daoProduto.alterar(pedido.getItemPedidos().get(i).getProduto());
                if (pedido.getFormaPagto()) {
                    daoCliente.alterar(cliente);
                }
            }
        }
    }//GEN-LAST:event_btnAlterarActionPerformed

    private void btnRemoverItemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnRemoverItemActionPerformed
        double subTotal;
        if (tblItens.getSelectedRow() == -1) {
            JOptionPane.showMessageDialog(null, "A linha não foi selecionada", "Aviso", JOptionPane.ERROR_MESSAGE);
        } else {
            modTblItens.removeRow(tblItens.getSelectedRow());
        }
    }//GEN-LAST:event_btnRemoverItemActionPerformed

    private void btnAdicionarItemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAdicionarItemActionPerformed
        double qtdeVendidaLbl = Double.parseDouble(txtQtdeVendida.getText());
        double subTotal, total = 0;
        
        modTblItens = (DefaultTableModel) tblItens.getModel();
        
        String Linha[] = {
            produto.getCodigo(),
            produto.getDescricao(),
            String.valueOf(produto.getPreco()),
            String.valueOf(qtdeVendidaLbl)
        };
        
        subTotal = qtdeVendidaLbl * produto.getPreco();
        
        total += subTotal;
        // não entendi como add esse cara no remover 
        
        modTblItens.addRow(Linha);
        
        modTblItens.setValueAt(subTotal , modTblItens.getRowCount() - 1, 4);

    }//GEN-LAST:event_btnAdicionarItemActionPerformed

    private void txtDataPedidoFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_txtDataPedidoFocusLost
        try {
            String data = txtDataPedido.getText();
            SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
            sdf.setLenient(false);
            Date dataPedido = sdf.parse(data);

            pedido = new Pedido(txtNumeroPedido.getText(), data);
        } catch (ParseException e) {
            JOptionPane.showMessageDialog(
                    this,
                    "Informe uma data valida.",
                    "ATENÇÃO",
                    JOptionPane.WARNING_MESSAGE
            );

        }
    }//GEN-LAST:event_txtDataPedidoFocusLost

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnAdicionarItem;
    private javax.swing.JButton btnAlterar;
    private javax.swing.JButton btnConsultarCliente;
    private javax.swing.JButton btnConsultarItemPedido;
    private javax.swing.JButton btnConsultarPedido;
    private javax.swing.JButton btnConsultarVendedor;
    private javax.swing.JButton btnExcluir;
    private javax.swing.JButton btnIncluir;
    private javax.swing.JButton btnRemoverItem;
    private javax.swing.JButton btnSair;
    private javax.swing.ButtonGroup buttonGroup1;
    private javax.swing.ButtonGroup buttonGroup2;
    private javax.swing.ButtonGroup buttonGroup3;
    private javax.swing.ButtonGroup buttonGroup4;
    private javax.swing.ButtonGroup buttonGroup5;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JTable jTable1;
    private javax.swing.JLabel lblCPFCliente;
    private javax.swing.JLabel lblCPFVendedor;
    private javax.swing.JLabel lblCliente;
    private javax.swing.JLabel lblCodigoProduto;
    private javax.swing.JLabel lblDataPedido;
    private javax.swing.JLabel lblNumeroPedido;
    private javax.swing.JLabel lblProduto;
    private javax.swing.JLabel lblQtdeItensPedido;
    private javax.swing.JLabel lblQtdeVendida;
    private javax.swing.JLabel lblQuantItensPedidos;
    private javax.swing.JLabel lblValorTotal;
    private javax.swing.JLabel lblValorTotalPedido;
    private javax.swing.JLabel lblVendedor;
    private javax.swing.JPanel painelFormaPagamento;
    private javax.swing.JPanel pnDadosCliente;
    private javax.swing.JPanel pnDadosPedido;
    private javax.swing.JPanel pnDadosVendedor;
    private javax.swing.JPanel pnItensDoPedido;
    private javax.swing.JRadioButton rdbtnPagamentoAPrazo;
    private javax.swing.JRadioButton rdbtnPagamentoAVista;
    private javax.swing.JTable tblItens;
    private javax.swing.JFormattedTextField txtCPFCliente;
    private javax.swing.JFormattedTextField txtCPFVendedor;
    private javax.swing.JTextField txtCodigoProduto;
    private javax.swing.JFormattedTextField txtDataPedido;
    private javax.swing.JTextField txtNumeroPedido;
    private javax.swing.JTextField txtQtdeVendida;
    // End of variables declaration//GEN-END:variables
    private DaoPedido daoPedido = null;
    private DaoCliente daoCliente = null;
    private DaoVendedor daoVendedor = null;
    private DaoProduto daoProduto = null;
    private DaoItemPedido daoItemPedido = null;

    private Cliente cliente = null;
    private Vendedor vendedor = null;
    private Produto produto = null;
    private Pedido pedido = null;
    private ItemPedido itemPedido = null;

    private Conexao conexao = null;
    private DecimalFormat df = null;

    private DefaultTableModel modTblItens = null;
}
